
#Importa los datos
getwd()
setwd("_")
getwd()
peliculas <- read.csv("Curso R - Secci�n 6 - Datos Pr�ctica.csv")

#An�lisis Exploratorio

_(peliculas) #filas superiores
_(peliculas) #resumen de las columnas
_(peliculas) #estructura del set de datos

#Activar GGPlot2
#Usar install.package("ggplot2") en caso de no tener el paquete descargado
library(_)

#Fuera de alcance pero esta interesante: 
ggplot(data=peliculas, aes(x=D�a.de.la.Semana..lanzamiento.)) + geom_bar()
#�Te das cuenta? No ha habido estrenos de pel�culas en un Lunes. 

#Ahora vamos a filtrar nuestro set de datos para dejar �nicamente
#los G�neros y los Estudios en los que estamos interesados
#Empezaremos con el filtro de G�nero. Usaremos el operador l�gico 
#"or" para seleccionar m�ltiples G�neros:
filtro1 <- (peliculas$G�nero == "acci�n") | (peliculas$G�nero == "aventura") | (peliculas$G�nero == "animaci�n") | (peliculas$G�nero == "comedia") | (peliculas$G�nero == "drama")

#Ahora hagamos lo mismo para los Estudios:
filtro2 <- (_ == "Buena Vista Studios") | (_ _ "WB") | (_ _ "Fox") _ (_ _ "Universal") _ (_ _ "Sony") _ (_ _ "Paramount Pictures")
  
#Aplica los filtros de las filas al marco de datos
peliculas2 <- peliculas[_ & _,]

#Prepara los datos del gr�fico y las capas de est�ticas
#Nota que no le cambiamos el nombre a las columnas
#Usa str() o summary() para encontrar el nombre correcto de las columnas
p <- ggplot(data=_, aes(x=_, y=_))
p #No pasa nada porque se necesita una geometr�a

#Agrega una capa con geometr�a de puntos
p + 
  _()

#Puedes agregar un boxplot en lugar de los puntos
p + 
  _()

#Nota que los valores at�picos son parte de la capa del boxplot
#Usaremos esa observaci�n despu�s (*)

#Agrega los puntos
p + 
  geom_boxplot() + 
  _()
#No es exactamente lo que est�bamos buscando

#Cambia los puntos por el jitter
p + 
  geom_boxplot() + 
  _()

#Posiciona el boxplot por encima del jitter
p + 
  _() + 
  _() 

#Agrega transparencia al boxplot
p + 
  _() + 
  _(alpha=0.7) 

#Ahora puedes agregar tama�o y color a los puntos:
p + 
  _(aes(_=Presupuesto...mill., _=Estudio)) + 
  _(_=0.7) 
#�Puedes ver los puntos negros que a�n est�n visibles?
#�De d�nde vienen?
#Son parte del boxplot - �Recuerdas la observaci�n (*) que hicimos arriba?

#Vamos a quitarlos:
p + 
  _(aes(_=Presupuesto...mill., _=Estudio)) + 
  _(_ = 0.7, outlier.colour = NA) 

#Almacenamos nuestro progreso en un nuevo objeto: 
q <- p + 
  _(aes(_=Presupuesto...mill., _=Estudio)) + 
  _(_ = 0.7, outlier.colour = NA) 
q

#Elementos que no son datos (non-data ink)
q <- q +
  _("G�nero") + #t�tulo del eje x
  _("% Ventas USA") + #t�tulo del eje y
  _("Domestic Gross % by Genre") #t�tulo del diagrama
q

#TIP: para la siguiente parte puedes usar ?theme si necesitas
#acordarte qu� par�metros son responsables de qu� 

#Tema
q <- q + 
  theme(
    #T�tulo de los ejes:
    _ = element_text(color="Blue", size=20),
    _ = element_text(color="Blue", size=20),
    
    #Texto de los ejes:
    _ = element_text(size=15),
    _ = element_text(size=15),  
    
    #T�tulo del gr�fico:
    _ = element_text(color="Black",
                              size=25, 
                              hjust = 0.5),
    
    #T�tulo de la Leyenda:
    _ = element_text(size=15),
    
    #Texto de la Leyenda
    _ = element_text(size=10)
  )
q

#Toque Final. Esto no lo hab�amos visto durante el curso
#Pero de esta manera puedes cambiar individualmente el t�tulo de tu leyenda
q$labels$size = "Presupuesto $M"
q

#Bien hecho!